package com.zr.model;

public class job {
	private int jid;
	private String jname;
	private String jtext;
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public String getJname() {
		return jname;
	}
	public void setJname(String jname) {
		this.jname = jname;
	}
	public String getJtext() {
		return jtext;
	}
	public void setJtext(String jtext) {
		this.jtext = jtext;
	}
	
	
}
