package com.zr.model;

import java.util.ArrayList;

import com.zr.dao.jobdao;
import com.zr.dao.notiondao;
import com.zr.dao.partdao;
import com.zr.dao.staffdao;
import com.zr.dao.textdao;
import com.zr.dao.userdao;

public class alltext {
	public static void main(String[] args) {
	    ArrayList<User> userList = userdao.quaryAll();
	    for(User user : userList){
	        System.out.println("查询出来的id是："+user.getId());
	        System.out.println("查询出来的名字是："+user.getName());
	        System.out.println("查询出来的年龄是："+user.getPassword());
	        System.out.println("查询出来的状态是："+user.getStatus());
	        System.out.println("查询出来的日期是："+user.getData());
	    }
	    
	    ArrayList<text> textList = textdao.quaryAll();
	    for(text text : textList){
	        System.out.println("查询出来的id是："+text.getTdata());
	        System.out.println("查询出来的名字是："+text.getText());
	        System.out.println("查询出来的年龄是："+text.getTsid());
	        System.out.println("查询出来的状态是："+text.getTtext());
	        System.out.println("查询出来的日期是："+text.getTid());
	    }  
	
	 ArrayList<staff> staffList = staffdao.quaryAll();
	    for(staff staff : staffList){
	        System.out.println("查询出来的id是："+staff.getSid());
	        System.out.println("查询出来的名字是："+staff.getSsname());
	        System.out.println("查询出来的年龄是："+staff.getSex());
	        System.out.println("查询出来的状态是："+staff.getPnumber());
	        System.out.println("查询出来的日期是："+staff.getEmail());
	    }
	   
	    ArrayList<part> partList =partdao.quaryAll();
	    for(part part : partList){
	        System.out.println("查询出来的id是："+part.getPid());
	        System.out.println("查询出来的名字是："+part.getSname());
	        System.out.println("查询出来的年龄是："+part.getText());
	          }
	
	    ArrayList<notion> notionList =notiondao.quaryAll();
	    for(notion notion : notionList){
	        System.out.println("查询出来的id是："+notion.getNid());
	        System.out.println("查询出来的名字是："+notion.getNname());
	        System.out.println("查询出来的年龄是："+notion.getNtext());
	          }
	    ArrayList<job> jobList =jobdao.quaryAll();
	    for(job job : jobList){
	        System.out.println("查询出来的id是："+job.getJid());
	        System.out.println("查询出来的名字是："+job.getJname());
	        System.out.println("查询出来的年龄是："+job.getJtext());
	          }
	
	}
	
}