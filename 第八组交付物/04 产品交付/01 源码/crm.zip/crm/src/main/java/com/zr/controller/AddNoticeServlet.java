package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.NoticeService;

public class AddNoticeServlet extends HttpServlet {

	private NoticeService noticeService = new NoticeService();
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");		
		PrintWriter out = resp.getWriter();
		int nid = Integer.parseInt(req.getParameter("nid"));
		String name = req.getParameter("name");
		String content = req.getParameter("content");
		String time = req.getParameter("time");		
		String uid = req.getParameter("uid");	
		noticeService.addNoticeService(nid,name,content,time,uid);
		out.flush();
		out.close();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
}
