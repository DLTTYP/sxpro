package com.zr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.zr.model.part;
import com.zr.util.JDBCUtil;

public class partdao {
	/**
     * 查询数据库里面所有的数据
     * @return
  */
 public static ArrayList<part> quaryAll(){
 Connection conn = null;
 PreparedStatement stmt = null;
 ResultSet rs = null;
 ArrayList<part> list = new ArrayList<part>();
 try {
     conn = JDBCUtil.getConnection();
     String sql = "select * from part;";
     stmt = conn.prepareStatement(sql);
     rs = stmt.executeQuery();
     while (rs.next()) {
    	 part item = new part();
         item.setSname(rs.getString("sname"));
         item.setText(rs.getString("text"));
         item.setPid(rs.getInt("pid"));
         
         list.add(item);
     }

     return list;
 } catch (Exception ex) {
     ex.printStackTrace();
     return null;
 } finally {
     if (rs != null) {
         try {
             rs.close();
             rs = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

     if (stmt != null) {
         try {
             stmt.close();
             stmt = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

 }
}
}
