package com.zr.service;

import java.util.List;

import com.zr.dao.Dao;
import com.zr.model.NoticeInfo;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class NoticeService {
	
	private Dao dao = new Dao();
	
	public boolean addNoticeService(int nid,String name, String content, String time,String uid
			) {
		
		//String uid = dao.getNoticeIdByName(name);
		return dao.addNotice(nid,name,content,time,uid);
	}
	
	public JSONObject searchNoticeService(String uid,String name) {
		JSONObject tree = new JSONObject();
		List<NoticeInfo> list = dao.getAllNotice(uid, name);
		tree.put("total", list.size());
		tree.put("rows", list);
		return tree;
	}
	
	public boolean deleteNoticeService(String nid) {
		
		JSONArray json = JSONArray.fromObject(nid);	
		for (int i=0;i < json.size();i++) {
			JSONObject tree = json.getJSONObject(i);
			dao.deleteNotice(tree.getString("nid"));
		}
		return true;
		
	}
}