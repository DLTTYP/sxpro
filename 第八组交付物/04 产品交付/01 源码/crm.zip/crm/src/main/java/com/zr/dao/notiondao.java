package com.zr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.zr.model.notion;
import com.zr.util.JDBCUtil;

public class notiondao {
	/**
     * 查询数据库里面所有的数据
     * @return
  */
 public static ArrayList<notion> quaryAll(){
 Connection conn = null;
 PreparedStatement stmt = null;
 ResultSet rs = null;
 ArrayList<notion> list = new ArrayList<notion>();
 try {
     conn = JDBCUtil.getConnection();
     String sql = "select * from notion;";
     stmt = conn.prepareStatement(sql);
     rs = stmt.executeQuery();
     while (rs.next()) {
    	 notion item = new notion();
         item.setNname(rs.getString("nname"));
         item.setNtext(rs.getString("ntext"));
         item.setNdata(rs.getString("ndata"));
         item.setCer(rs.getString("cer"));
         item.setNid(rs.getInt("nid"));
         
         list.add(item);
     }

     return list;
 } catch (Exception ex) {
     ex.printStackTrace();
     return null;
 } finally {
     if (rs != null) {
         try {
             rs.close();
             rs = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

     if (stmt != null) {
         try {
             stmt.close();
             stmt = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

 }
}
}
