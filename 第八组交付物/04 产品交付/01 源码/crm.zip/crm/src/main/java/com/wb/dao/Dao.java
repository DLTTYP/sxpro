package com.wb.dao;

/**
 *  数据库的相关操作
 * 
 * **/
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.wb.model.DeptInfo;
import com.wb.model.NoticeInfo;
import com.wb.model.PostInfo;
import com.wb.model.UserInfo;
import com.wb.model.WorkersInfo;

public class Dao {

	private SqlBean db = new SqlBean();
	private Connection conn;
	private PreparedStatement stmt = null;

	/**
	 * @exception 检测数据库连接状态
	 * 
	 **/
	public void checkConnect() {
		try {
			if (conn == null || conn.isClosed()) {
				conn = db.getConnection();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @exception 获得部门id最大值
	 * @return boolean
	 * 
	 **/
	public int getMaxDeptId() {
		checkConnect();
		String sql = "select max(did) as maxNo from tb_dept";
		try {
			stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return rs.getInt("maxNo");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	/**
	 * @exception 获得部门id
	 * @return int
	 * 
	 **/
	public int getDeptIdByName(String name) {
		checkConnect();
		String sql = "select did from tb_dept where name = '" + name + "'";
		try {
			stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				return rs.getInt("did");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	/**
	 * @exception 获得部门名
	 * @return String
	 * 
	 **/
	public String getDeptNameById(int did) {
		checkConnect();
		String sql = "select name from tb_dept where did = '" + did + "'";
		try {
			PreparedStatement stmt1 = conn.prepareStatement(sql);
			ResultSet rs = stmt1.executeQuery();
			if (rs.next()) {
				return rs.getString("name");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "";
	}

	/**
	 * @exception 通过部门名查找部门的list集合
	 * @return list
	 * 
	 **/
	public List<DeptInfo> getAllDept() {
		checkConnect();
		List<DeptInfo> list_dept = new ArrayList<DeptInfo>();
		String sql = "";
		sql = "select * from tb_dept";

		try {
			stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				DeptInfo dept = new DeptInfo();
				dept.setDid(rs.getInt("did"));
				dept.setName(rs.getString("name"));
				dept.setInfo(rs.getString("info"));
				list_dept.add(dept);
			}
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list_dept;
	}

	/**
	 * @exception 删除部门
	 * @return boolean
	 * 
	 **/
	public boolean deleteDept(String did) {
		checkConnect();
		String sql = "delete from tb_dept where did = " + did;
		try {
			stmt = conn.prepareStatement(sql);
			stmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * @exception 添加部门信息
	 * @return boolean
	 * 
	 **/
	public boolean addDept(String name, String info) {
		int did = getMaxDeptId() + 1;
		checkConnect();
		String sql = "insert into tb_dept (did,name,info) values (?,?,?)";
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, did);
			stmt.setString(2, name);
			stmt.setString(3, info);
			stmt.executeUpdate();
			conn.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}


	
}
