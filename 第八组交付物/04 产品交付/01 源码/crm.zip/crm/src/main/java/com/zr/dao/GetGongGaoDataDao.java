package com.zr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import com.zr.model.GongGao;
import com.zr.util.JDBCUtil;

public class GetGongGaoDataDao {

   public List<GongGao>  gettestGongGao(){
	   List<GongGao>  tgg = new ArrayList<GongGao>();
	   //从数据库中获取封装
	   try {
		Connection  con = JDBCUtil.getConnection();
		String sql = "select * from testgonggao";
		PreparedStatement  pst = con.prepareStatement(sql);
		ResultSet  rs = pst.executeQuery();
		while (rs.next()) {
			GongGao G = new GongGao();
			G.setGid(rs.getInt("gid"));
			G.setGname(rs.getString("gname"));
			G.setGcontent(rs.getString("gcontent"));
			G.setGtime(rs.getString("gtime"));
			G.setGpeople(rs.getString("gpeople"));
			tgg.add(G);
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
	   return tgg;
   }
   
}