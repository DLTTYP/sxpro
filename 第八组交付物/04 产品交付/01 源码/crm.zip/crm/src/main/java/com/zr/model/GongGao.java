package com.zr.model;

public class GongGao {
	private int gid;
	private String gname;
	private String gcontent;
	private String gtime;
	private String gpeople;
	
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	
	public String getGcontent() {
		return gcontent;
	}
	public void setGcontent(String gcontent) {
		this.gcontent = gcontent;
	}
	
	public String getGtime() {
		return gtime;
	}
	public void setGtime(String gtime) {
		this.gtime = gtime;
	}
	
	public String getGpeople() {
		return gpeople;
	}
	public void setGpeople(String gpeople) {
		this.gpeople = gpeople;
	}
	public GongGao(int gid,String gname,String gcontent,String gtime,String gpeople ) {
		super();
		this.gname = gname;
		this.gcontent = gcontent;

		this.gtime = gtime;
		this.gpeople = gpeople;
	}
	public GongGao() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
