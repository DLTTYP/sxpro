package com.zr.model;

public class text {
	private int tid;
	private String text;
	private String tdata;
	private String tsid;
	private String ttext;
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getTdata() {
		return tdata;
	}
	public void setTdata(String tdata) {
		this.tdata = tdata;
	}
	public String getTsid() {
		return tsid;
	}
	public void setTsid(String tsid) {
		this.tsid = tsid;
	}
	public String getTtext() {
		return ttext;
	}
	public void setTtext(String ttext) {
		this.ttext = ttext;
	}
	
	
}
