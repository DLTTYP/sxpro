package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zr.dao.userdao;
import com.zr.model.User;
import com.zr.service.LoginService;
import com.zr.util.JDBCUtil;

public class LoginController extends HttpServlet{
    userdao userdao=new userdao();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//假定你拿到数据之后，我们就可以做对应的逻辑处理
		 String username=request.getParameter("username");
	        String password=request.getParameter("password");
	        Connection con=null;
	        try {
	        	ArrayList<User> userList = userdao.quaryAll();
	                for(int i=0;i<userList.size();i++) {
	               User uu= userList.get(i);
	              String un=uu.getName();
	              String up= uu.getPassword();
	              if( un.equals(username) && password.equals(up)){
	            	  //System.out.println("yes");
		                HttpSession session=request.getSession();
		                session.setAttribute("currentUser",userList);
		                response.sendRedirect("main.jsp");		                
		            }else{		               
		              //System.out.println("no");
		                request.setAttribute("error", "用户名或者密码错误");
		                request.setAttribute("username", username);
		                request.setAttribute("password", password);
		                request.getRequestDispatcher("login.jsp").forward(request, response);
		            } 	                	
	                }	            
	        } catch (Exception e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }	        
	    }


		
	

}
