package com.zr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.zr.model.staff;
import com.zr.util.JDBCUtil;

public class staffdao {
	/**
     * 查询数据库里面所有的数据
     * @return
  */
 public static ArrayList<staff> quaryAll(){
 Connection conn = null;
 PreparedStatement stmt = null;
 ResultSet rs = null;
 ArrayList<staff> list = new ArrayList<staff>();
 try {
     conn = JDBCUtil.getConnection();
     String sql = "select * from staff;";
     stmt = conn.prepareStatement(sql);
     rs = stmt.executeQuery();
     while (rs.next()) {
    	 staff item = new staff();
         item.setSid(rs.getString("sid"));
         item.setSsname(rs.getString("ssname"));
         item.setSex(rs.getString("sex"));
         item.setPnumber(rs.getString("pnumber"));
         item.setEmail(rs.getString("email"));
         item.setJname(rs.getString("jname"));
         item.setEb(rs.getString("eb"));
         item.setIdc(rs.getString("idc"));
         item.setSname(rs.getString("sname"));
         item.setAddress(rs.getString("address"));
         item.setBdata(rs.getString("bdata"));
         list.add(item);
     }

     return list;
 } catch (Exception ex) {
     ex.printStackTrace();
     return null;
 } finally {
     if (rs != null) {
         try {
             rs.close();
             rs = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

     if (stmt != null) {
         try {
             stmt.close();
             stmt = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

 }
}
}
