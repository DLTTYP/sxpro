package com.zr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.zr.model.job;
import com.zr.util.JDBCUtil;

public class jobdao {
	/**
     * 查询数据库里面所有的数据
     * @return
  */
 public static ArrayList<job> quaryAll(){
 Connection conn = null;
 PreparedStatement stmt = null;
 ResultSet rs = null;
 ArrayList<job> list = new ArrayList<job>();
 try {
     conn = JDBCUtil.getConnection();
     String sql = "select * from job;";
     stmt = conn.prepareStatement(sql);
     rs = stmt.executeQuery();
     while (rs.next()) {
    	 job item = new job();
         item.setJname(rs.getString("jname"));
         item.setJtext(rs.getString("jtext"));
         item.setJid(rs.getInt("jid"));
         
         list.add(item);
     }

     return list;
 } catch (Exception ex) {
     ex.printStackTrace();
     return null;
 } finally {
     if (rs != null) {
         try {
             rs.close();
             rs = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

     if (stmt != null) {
         try {
             stmt.close();
             stmt = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

 }
}
}
