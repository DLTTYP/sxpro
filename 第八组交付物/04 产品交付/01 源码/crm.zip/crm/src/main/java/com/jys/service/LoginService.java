package com.jys.service;

import com.zr.model.User;
/**
 * 
 * @author wwj
 *  取决你需不需进行持久化的操作
 */
public class LoginService {

	/**
	 * 通过用户名xxxxx
	 * @param uname  用户名字
	 * @return 返回用户对象
	 */
	public String loginByName(String uname){
		
		return "abcd";
	}
}
