package com.zr.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.zr.model.text;
import com.zr.util.JDBCUtil;

public class textdao {
	/**
     * 查询数据库里面所有的数据
     * @return
  */
 public static ArrayList<text> quaryAll(){
 Connection conn = null;
 PreparedStatement stmt = null;
 ResultSet rs = null;
 ArrayList<text> list = new ArrayList<text>();
 try {
     conn = JDBCUtil.getConnection();
     String sql = "select * from text;";
     stmt = conn.prepareStatement(sql);
     rs = stmt.executeQuery();
     while (rs.next()) {
         text item = new text();
         item.setText(rs.getString("text"));
         item.setTdata(rs.getString("tdata"));
         item.setTsid(rs.getString("tsid"));
         item.setTtext(rs.getString("ttext"));
         item.setTid(rs.getInt("tid"));
         list.add(item);
     }

     return list;
 } catch (Exception ex) {
     ex.printStackTrace();
     return null;
 } finally {
     if (rs != null) {
         try {
             rs.close();
             rs = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

     if (stmt != null) {
         try {
             stmt.close();
             stmt = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

 }
}
}
