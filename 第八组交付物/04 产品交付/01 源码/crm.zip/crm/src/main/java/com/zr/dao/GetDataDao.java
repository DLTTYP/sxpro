package com.zr.dao;

public class GetDataDao {

	
	
}
