package com.zr.model;

public class notion {
	private int nid;
	private String nname;
	private String ntext;
	private String ndata;
	private String cer;
	public int getNid() {
		return nid;
	}
	public void setNid(int nid) {
		this.nid = nid;
	}
	public String getNname() {
		return nname;
	}
	public void setNname(String nname) {
		this.nname = nname;
	}
	public String getNtext() {
		return ntext;
	}
	public void setNtext(String ntext) {
		this.ntext = ntext;
	}
	public String getNdata() {
		return ndata;
	}
	public void setNdata(String ndata) {
		this.ndata = ndata;
	}
	public String getCer() {
		return cer;
	}
	public void setCer(String cer) {
		this.cer = cer;
	}
	
	
}
