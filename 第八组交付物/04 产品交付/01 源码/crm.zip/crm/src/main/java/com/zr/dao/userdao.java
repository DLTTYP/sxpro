package com.zr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.zr.model.User;
import com.zr.util.JDBCUtil;

public class userdao {
	/**
     * 查询数据库里面所有的数据
     * @return
  */
 public static ArrayList<User> quaryAll(){
 Connection conn = null;
 PreparedStatement stmt = null;
 ResultSet rs = null;
 ArrayList<User> list = new ArrayList<User>();
 try {
     conn = JDBCUtil.getConnection();
     String sql = "select * from user";
     stmt = conn.prepareStatement(sql);
     rs = stmt.executeQuery();
     while (rs.next()) {
         User item = new User();
        item.setPassword(rs.getString("password"));
         item.setName(rs.getString("name"));
         item.setId(rs.getInt("id"));
         item.setStatus(rs.getInt("status"));
         item.setData(rs.getString("data"));
         list.add(item);
     }

     return list;
 } catch (Exception ex) {
     ex.printStackTrace();
     return null;
 } finally {
     if (rs != null) {
         try {
             rs.close();
             rs = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

     if (stmt != null) {
         try {
             stmt.close();
             stmt = null;
         } catch (Exception e) {
             e.printStackTrace();
         }
     }

 }
}
}
