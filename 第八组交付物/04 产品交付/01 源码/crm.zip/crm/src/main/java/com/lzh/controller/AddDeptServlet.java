package com.lzh.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.crypto.spec.RC2ParameterSpec;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lzh.service.DeptService;

public class AddDeptServlet extends HttpServlet {
	
	private DeptService deptService = new DeptService();
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		PrintWriter out = resp.getWriter();
		String name = req.getParameter("deptName");
		String describe = req.getParameter("describe");		
		deptService.addDeptService(name, describe);
		out.flush();
		out.close();
	}
		
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	
}
