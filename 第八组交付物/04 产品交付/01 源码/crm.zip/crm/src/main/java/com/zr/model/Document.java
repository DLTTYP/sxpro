package com.zr.model;

public class Document {
	private String bt;
	private String cjsj;
	private String cjr;
	private String ms;

	public String getBt() {
		return bt;
	}

	public void setBt(String bt) {
		this.bt = bt;
	}

	public String getCjsj() {
		return cjsj;
	}

	public void setCjsj(String cjsj) {
		this.cjsj = cjsj;
	}

	public String getCjr() {
		return cjr;
	}

	public void setCjr(String cjr) {
		this.cjr = cjr;
	}

	public String getMs() {
		return ms;
	}

	public void setMs(String ms) {
		this.ms = ms;
	}

	public Document(String bt, String cjsj, String cjr, String ms) {
		super();
		this.bt = bt;
		this.cjsj = cjsj;
		this.cjr = cjr;
		this.ms = ms;
	}

	public Document() {
		super();
		// TODO Auto-generated constructor stub
	}

}
